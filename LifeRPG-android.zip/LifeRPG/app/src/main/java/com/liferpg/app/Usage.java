package com.liferpg.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;

/** アプリごとの今日の使用時間（ミリ秒）を自分で記録する。日付が変わるとリセット */
public class Usage {
    static final String PREF = "usage";

    static String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }

    private static JSONObject load(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        try {
            if (!today().equals(p.getString("date", ""))) return new JSONObject();
            return new JSONObject(p.getString("map", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    static void add(Context c, String pkg, long ms) {
        if (pkg == null || ms <= 0) return;
        ms = Math.min(ms, 6L * 3600 * 1000); // 異常値よけ
        try {
            JSONObject m = load(c);
            m.put(pkg, m.optLong(pkg, 0) + ms);
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("date", today()).putString("map", m.toString()).apply();
        } catch (Exception ignored) { }
    }

    static long used(Context c, String pkg) { return load(c).optLong(pkg, 0); }

    static String todayMinutes(Context c) {
        JSONObject m = load(c), out = new JSONObject();
        try {
            Iterator<String> it = m.keys();
            while (it.hasNext()) {
                String k = it.next();
                out.put(k, m.optLong(k, 0) / 60000.0);
            }
        } catch (Exception ignored) { }
        return out.toString();
    }

    /** 制限（分）。なければ -1 */
    static long limitMin(Context c, String pkg) {
        try {
            JSONObject l = new JSONObject(c.getSharedPreferences(Bridge.PREF, Context.MODE_PRIVATE).getString("limits", "{}"));
            return l.has(pkg) ? l.optLong(pkg, -1) : -1;
        } catch (Exception e) {
            return -1;
        }
    }
}
