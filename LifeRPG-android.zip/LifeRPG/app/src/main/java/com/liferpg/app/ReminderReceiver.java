package com.liferpg.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** リマインダーの時刻に通知を出す。再起動・アップデート後はアラームを登録し直す */
public class ReminderReceiver extends BroadcastReceiver {
    static final String CHANNEL = "remind";

    @Override
    public void onReceive(Context c, Intent intent) {
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            Reminders.scheduleAll(c);
            return;
        }
        int rid = intent.getIntExtra("rid", -1);
        JSONArray arr = Reminders.list(c);
        JSONObject r = null;
        for (int k = 0; k < arr.length(); k++) {
            JSONObject o = arr.optJSONObject(k);
            if (o != null && o.optInt("id") == rid) { r = o; break; }
        }
        if (r != null && r.optBoolean("on", true) && !alreadyDone(c, r.optString("quest", ""))) {
            notify(c, rid, r.optString("title", "リマインダー"), r.optString("text", ""));
        }
        Reminders.scheduleAll(c); // 次の日の分を登録
    }

    private boolean alreadyDone(Context c, String questId) {
        if (questId.isEmpty()) return false;
        SharedPreferences p = Reminders.prefs(c);
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        if (!today.equals(p.getString("doneDate", ""))) return false;
        return p.getString("doneIds", "[]").contains("\"" + questId + "\"");
    }

    private void notify(Context c, int rid, String title, String text) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,
                c.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_DEFAULT));
        Intent open = new Intent(c, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("reminder", rid);
        PendingIntent pi = PendingIntent.getActivity(c, 10000 + rid, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        try {
            nm.notify(rid, n);
        } catch (SecurityException ignored) { } // 通知が許可されていない
    }
}
