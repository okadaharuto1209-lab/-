package com.liferpg.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;

/** Health Connect の権限画面から開かれる「健康データの使い道」 */
public class PermissionsRationaleActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        TextView tv = new TextView(this);
        tv.setText(getString(R.string.rationale_title) + "\n\n" + getString(R.string.rationale_body));
        tv.setTextColor(Color.parseColor("#EEF0F5"));
        tv.setTextSize(16);
        tv.setLineSpacing(0, 1.4f);
        tv.setPadding(pad, pad, pad, pad);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#121830"));
        sv.addView(tv);
        setContentView(sv);
    }
}
