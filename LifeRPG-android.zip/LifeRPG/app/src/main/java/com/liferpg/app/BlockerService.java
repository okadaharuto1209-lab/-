package com.liferpg.app;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

import org.json.JSONArray;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 前面に出たアプリを見て、
 * ・必須クエスト未クリアのロック対象アプリ → ブロック
 * ・1日の時間制限を使い切ったアプリ → ブロック
 * あわせて、アプリごとの使用時間を記録する（画面オフ中は数えない）。
 */
public class BlockerService extends AccessibilityService {

    private long lastBlockAt = 0;
    private String curPkg = null;
    private long curStart = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable limitCheck = this::checkCurrentLimit;

    private final BroadcastReceiver screenOff = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) { flush(); curPkg = null; handler.removeCallbacks(limitCheck); }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        registerReceiver(screenOff, new IntentFilter(Intent.ACTION_SCREEN_OFF));
    }

    @Override
    public void onDestroy() {
        try { unregisterReceiver(screenOff); } catch (Exception ignored) { }
        flush();
        super.onDestroy();
    }

    private void flush() {
        if (curPkg != null) Usage.add(this, curPkg, System.currentTimeMillis() - curStart);
        curStart = System.currentTimeMillis();
    }

    private static boolean ignorable(String pkg) {
        return pkg.equals("com.android.systemui") || pkg.contains("inputmethod") || pkg.contains("keyboard");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence pc = event.getPackageName();
        if (pc == null) return;
        String pkg = pc.toString();
        if (ignorable(pkg)) return;

        // 使用時間の記録
        if (!pkg.equals(curPkg)) {
            flush();
            curPkg = pkg;
            curStart = System.currentTimeMillis();
            handler.removeCallbacks(limitCheck);
        }
        if (pkg.equals(getPackageName())) return;
        if (Launcher.essentials(this).contains(pkg)) return; // 電話・SMS・設定は絶対に止めない

        if (shouldBlock(pkg)) { block(pkg, false); return; }

        long lim = Usage.limitMin(this, pkg);
        if (lim >= 0) {
            long remain = lim * 60_000L - Usage.used(this, pkg);
            if (remain <= 0) { block(pkg, true); return; }
            handler.postDelayed(limitCheck, remain + 500); // 使っている途中で時間切れになったら止める
        }
    }

    private void checkCurrentLimit() {
        if (curPkg == null) return;
        flush();
        long lim = Usage.limitMin(this, curPkg);
        if (lim < 0) return;
        long remain = lim * 60_000L - Usage.used(this, curPkg);
        if (remain <= 0) block(curPkg, true);
        else handler.postDelayed(limitCheck, remain + 500);
    }

    private void block(String pkg, boolean limit) {
        long now = System.currentTimeMillis();
        if (now - lastBlockAt < 800) return; // 連続発火よけ
        lastBlockAt = now;
        flush();
        performGlobalAction(GLOBAL_ACTION_HOME);
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.putExtra(limit ? "limited" : "blocked", pkg);
        startActivity(i);
    }

    private boolean shouldBlock(String pkg) {
        SharedPreferences p = getSharedPreferences(Bridge.PREF, Context.MODE_PRIVATE);
        if (!p.getBoolean("enabled", false)) return false;
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        if (today.equals(p.getString("cleared", ""))) return false;
        if (System.currentTimeMillis() < p.getLong("passUntil", 0)) return false;
        try {
            JSONArray arr = new JSONArray(p.getString("blocked", "[]"));
            for (int k = 0; k < arr.length(); k++) if (pkg.equals(arr.optString(k))) return true;
        } catch (Exception ignored) { }
        return false;
    }

    @Override
    public void onInterrupt() { }
}
