package com.liferpg.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.ComponentActivity;

import org.json.JSONObject;

/** ゲーム画面（assets/index.html）を表示するメイン画面 */
public class MainActivity extends ComponentActivity {

    private WebView web;
    private boolean pageReady = false;
    private String pendingJs = null;
    HealthBridge health;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);      // localStorage でセーブ
        s.setDatabaseEnabled(true);
        s.setTextZoom(100);
        s.setAllowFileAccess(true);       // アイコン画像（端末内に保存）を表示するため
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                flush();
            }
        });
        health = new HealthBridge(this, web);   // 権限ダイアログの登録は onCreate 中に
        web.addJavascriptInterface(new Bridge(this), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        handleIntent(getIntent());
        cleanupOldAlarms();
    }

    /** 前のバージョンのアラーム機能で登録したアラームを取り消す（1回だけ） */
    private void cleanupOldAlarms() {
        android.content.SharedPreferences p = getSharedPreferences("lock", MODE_PRIVATE);
        if (p.getBoolean("alarmsCleaned", false)) return;
        android.app.AlarmManager am = (android.app.AlarmManager) getSystemService(ALARM_SERVICE);
        if (am != null) {
            android.content.ComponentName cn = new android.content.ComponentName(getPackageName(), getPackageName() + ".AlarmReceiver");
            for (int id = 1; id <= 60; id++) {
                for (int base : new int[]{20000, 40000}) {
                    Intent i = new Intent().setComponent(cn);
                    android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(this, base + id, i,
                            android.app.PendingIntent.FLAG_NO_CREATE | android.app.PendingIntent.FLAG_IMMUTABLE);
                    if (pi != null) { am.cancel(pi); pi.cancel(); }
                }
            }
        }
        getSharedPreferences("alarms", MODE_PRIVATE).edit().clear().apply();
        p.edit().putBoolean("alarmsCleaned", true).apply();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        String pkg = intent.getStringExtra("blocked");
        if (pkg != null) {
            String label = Bridge.labelOf(this, pkg);
            pendingJs = "window.onBlocked&&window.onBlocked(" + JSONObject.quote(pkg) + "," + JSONObject.quote(label) + ")";
            intent.removeExtra("blocked");
        }
        if (Intent.ACTION_MAIN.equals(intent.getAction()) && intent.hasCategory(Intent.CATEGORY_HOME)) {
            pendingJs = "window.onHome&&window.onHome()";   // ホームボタンで開かれた
        }
        String lim = intent.getStringExtra("limited");
        if (lim != null) {
            String label = Bridge.labelOf(this, lim);
            pendingJs = "window.onLimited&&window.onLimited(" + JSONObject.quote(lim) + "," + JSONObject.quote(label) + ")";
            intent.removeExtra("limited");
        }
        int rid = intent.getIntExtra("reminder", -1);
        if (rid >= 0) {
            pendingJs = "window.onReminderOpen&&window.onReminderOpen(" + rid + ")";
            intent.removeExtra("reminder");
        }
        flush();
    }

    private void flush() {
        if (!pageReady || pendingJs == null) return;
        String js = pendingJs;
        pendingJs = null;
        web.evaluateJavascript(js, null);
    }

    /** バックグラウンドの処理からゲームに結果を渡す */
    void js(String code) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    /** Android 13 以降の通知の許可 */
    void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            runOnUiThread(() -> requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 7 && pageReady) {
            web.evaluateJavascript("window.onAppResume&&window.onAppResume()", null);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (pageReady) web.evaluateJavascript("window.onAppResume&&window.onAppResume()", null);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.onBack&&window.onBack())?'1':'0'", value -> {
            if (value != null && value.contains("1")) return;
            if (Launcher.enabled(MainActivity.this) && Launcher.isDefaultHome(MainActivity.this)) return; // ホーム画面は閉じない
            finish();
        });
    }
}
