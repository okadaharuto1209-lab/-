package com.liferpg.app;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Process;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

/** その日の「画面に出ていた時間」をアプリごとに集計する（ホーム画面・このアプリ自身は除く） */
public class ScreenTime {

    static boolean granted(Context c) {
        AppOpsManager ops = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
        if (ops == null) return false;
        @SuppressWarnings("deprecation")
        int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    /** daysAgo=0 で今日（0時〜今）、1 で昨日（0時〜24時） */
    static String collect(Context c, int daysAgo) {
        JSONObject out = new JSONObject();
        try {
            if (!granted(c)) {
                out.put("granted", false);
                return out.toString();
            }
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            cal.add(Calendar.DAY_OF_MONTH, -daysAgo);
            long start = cal.getTimeInMillis();
            long end = daysAgo == 0 ? System.currentTimeMillis() : start + 24L * 3600 * 1000;

            HashSet<String> skip = new HashSet<>();
            skip.add(c.getPackageName());
            skip.add("com.android.systemui");
            PackageManager pm = c.getPackageManager();
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            for (ResolveInfo r : pm.queryIntentActivities(home, 0)) skip.add(r.activityInfo.packageName);

            UsageStatsManager usm = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
            UsageEvents ev = usm.queryEvents(start - 3L * 3600 * 1000, end); // 0時をまたいで開いていたアプリも拾う
            UsageEvents.Event e = new UsageEvents.Event();
            HashMap<String, Long> open = new HashMap<>();
            HashMap<String, Long> total = new HashMap<>();
            HashMap<String, Long> late = new HashMap<>();   // 0時〜4時（夜ふかし判定）
            long lateEnd = Math.min(end, start + 4L * 3600 * 1000);
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                String p = e.getPackageName();
                int t = e.getEventType();
                long ts = e.getTimeStamp();
                if (t == 1) {                       // 前面に出た（ACTIVITY_RESUMED）
                    if (!open.containsKey(p)) open.put(p, ts);
                } else if (t == 2 || t == 23) {     // 後ろに下がった（PAUSED / STOPPED）
                    Long s = open.remove(p);
                    if (s != null) add(total, p, s, ts, start, end);
                    add(late, p, s, ts, start, lateEnd);
                } else if (t == 16 || t == 26) {    // 画面オフ・端末シャットダウン
                    for (Map.Entry<String, Long> o : open.entrySet()) {
                        add(total, o.getKey(), o.getValue(), ts, start, end);
                        add(late, o.getKey(), o.getValue(), ts, start, lateEnd);
                    }
                    open.clear();
                }
            }
            for (Map.Entry<String, Long> o : open.entrySet()) {
                add(total, o.getKey(), o.getValue(), end, start, end);
                add(late, o.getKey(), o.getValue(), end, start, lateEnd);
            }
            long lateSum = 0;
            for (Map.Entry<String, Long> en : late.entrySet()) if (!skip.contains(en.getKey())) lateSum += en.getValue();

            long sum = 0;
            List<Map.Entry<String, Long>> list = new ArrayList<>();
            for (Map.Entry<String, Long> en : total.entrySet()) {
                if (skip.contains(en.getKey())) continue;
                sum += en.getValue();
                list.add(en);
            }
            list.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
            JSONArray apps = new JSONArray();
            for (Map.Entry<String, Long> en : list) {
                long min = en.getValue() / 60000;
                if (min < 1) continue;
                JSONObject o = new JSONObject();
                o.put("pkg", en.getKey());
                o.put("label", Bridge.labelOf(c, en.getKey()));
                o.put("min", min);
                apps.put(o);
            }
            out.put("granted", true);
            out.put("totalMin", sum / 60000);
            out.put("lateMin", lateSum / 60000);
            out.put("apps", apps);
        } catch (Exception ex) {
            try { out.put("error", String.valueOf(ex.getMessage())); } catch (Exception ignored) { }
        }
        return out.toString();
    }

    private static void add(HashMap<String, Long> total, String p, long s, long e, long start, long end) {
        long a = Math.max(s, start), b = Math.min(e, end);
        if (b <= a) return;
        Long cur = total.get(p);
        total.put(p, (cur == null ? 0 : cur) + (b - a));
    }
}
